import { Component, OnInit ,VERSION  } from '@angular/core';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-society',
  templateUrl: './society.component.html',
  styleUrls: ['./society.component.css']
})
export class SocietyComponent implements OnInit {

  constructor(private loginService: LoginService, private route: Router) { }
  searchText: any;
  allSociety: any;
  allBlockData: any;
  pages: number = 1;
  

  ngOnInit(): void {
    this.route.navigateByUrl('[/dashboard]')





    this.loginService.getSociety().subscribe((res: any) => {
      this.allSociety = res.response;
      console.log(res);
    });
  }
  onDetail(id: string) {
    console.log(id)
    this.route.navigateByUrl(`/block/${id}`);
  }


}

