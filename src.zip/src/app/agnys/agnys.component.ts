import { Component } from '@angular/core';

@Component({
  selector: 'app-agnys',
  templateUrl: './agnys.component.html',
  styleUrls: ['./agnys.component.css']
})
export class AgnysComponent {

    }
  


