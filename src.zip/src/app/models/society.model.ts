export interface SocietyModel {
    readonly societyname: string | null;
    readonly pincodeModel: PincodeModel

}

export interface PincodeModel {
    readonly pincodeId: number | null;
}

export interface CityModle {

    readonly cityname: String | null;
    readonly stateEntity: StateEntity
}

export interface StateEntity {
    readonly stateid: number | null;
}

export interface PincodeNumber {
    readonly pincodeNumber: String | null;
    readonly CityEntity: CityEntity

}
export interface CityEntity {
    readonly cityid: number;

}