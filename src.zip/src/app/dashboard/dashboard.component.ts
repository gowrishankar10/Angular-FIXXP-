import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { EChartsOption } from 'echarts';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {


  options: EChartsOption = {
    color: ['#3398DB'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
      },
    },
    grid: {

      left: '10%',
      right: '10%',
      bottom: '20%',
      containLabel: true,
    },
    xAxis: [

    ],
    yAxis: [
      {
        type: 'value',
      },
    ],
    series: [
      {
        name: 'Counters',
        type: 'bar',
        barWidth: '20%',
        data: [2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500, 7000, 6500],
      },
    ],
  };

  constructor(private loginService: LoginService, private router: Router) { }
  AlldashboardData: any;
  alltransaction: any;

  ngOnInit(): void {

    this.router.navigateByUrl('[/dashboard]')

    this.loginService.getdashboard().subscribe((res: any) => {
      this.AlldashboardData = res.response;
      console.log(res);
    });
    this.loginService.getAllTransaction().subscribe((res: any) => {
      this.options.xAxis = [
        {
          type: 'category',
          data: ["nov", 'dec', 'sep'],
          axisTick: {
            alignWithLabel: true,
          },
        },
      ]
      this.options.yAxis = [
        {
          type: 'category',
          data: [700, 8000, 90000],
          axisTick: {
            alignWithLabel: true,
          },
        },
      ]
      console.log(res);
    });


  }

}